import streamlit as st
import pandas as pd
import random
from datetime import datetime
from fpdf import FPDF  # Importing FPDF for PDF generation

# --------- Load Existing Data or Create New ---------
try:
    df = pd.read_csv("data.csv")
except FileNotFoundError:
    df = pd.DataFrame(columns=["Date", "Mood", "Chakra", "Dream", "Rituals", "Moon Phase", "Notes"])

# --------- Dashboard Header ---------
st.set_page_config(page_title="Spiritual Wellness Dashboard", layout="centered")
st.title(" Spiritual Wellness Dashboard")
st.write("Track your moods, chakras, dreams, and rituals daily.")

# --------- Chakra Diagram Image ---------
st.image("assets/chakras.png", caption="Chakra Alignment Guide", use_container_width=True)

# --------- Daily Input Section ---------
st.subheader(" Daily Check-In")

date = datetime.now().strftime("%Y-%m-%d")
mood = st.selectbox("How are you feeling today?", ["Peaceful", "Anxious", "Tired", "Grateful", "Empowered"])
chakra = st.selectbox("Which chakra needs attention?", ["Root", "Sacral", "Solar Plexus", "Heart", "Throat", "Third Eye", "Crown"])
dream = st.text_area(" Did you dream last night? What happened?")
rituals = st.multiselect(" Rituals practiced today:", ["Phahla", "Prayer", "Meditation", "Bath", "Breathwork", "Grounding"])

# --------- Manual Moon Phase Selection ---------
moon_phase = st.selectbox(" Current Moon Phase:", [
    "New Moon 🌑", "Waxing Crescent 🌒", "First Quarter 🌓",
    "Waxing Gibbous 🌔", "Full Moon 🌕", "Waning Gibbous 🌖",
    "Last Quarter 🌗", "Waning Crescent 🌘"
])

notes = st.text_area(" Messages, downloads, or reflections?")

# --------- Affirmation Generator ---------
affirmations = {
    "Root": ["I am grounded and safe.", "I trust the journey I am on."],
    "Sacral": ["I honor my emotions.", "I embrace pleasure and joy."],
    "Solar Plexus": ["I am powerful and confident.", "My will aligns with my purpose."],
    "Heart": ["I am love and I am loved.", "My heart is open to receive and give love."],
    "Throat": ["I speak my truth clearly.", "My voice matters."],
    "Third Eye": ["I trust my intuition.", "I see clearly within and without."],
    "Crown": ["I am connected to divine wisdom.", "I surrender to higher guidance."]
}

if st.button("🪷 Get Affirmation"):
    affirmation = random.choice(affirmations.get(chakra, ["You are aligned."]))
    st.success(affirmation)

# --------- Save Entry ---------
if st.button(" Save Entry"):
    new_entry = pd.DataFrame([[date, mood, chakra, dream, ", ".join(rituals), moon_phase, notes]],
                             columns=df.columns)
    df = pd.concat([df, new_entry], ignore_index=True)
    df.to_csv("data.csv", index=False)
    st.success(" Entry saved successfully!")

# --------- Show Recent Entries ---------
st.subheader(" Recent Entries")
if not df.empty:
    st.dataframe(df.tail(10))
else:
    st.info("No entries yet.")

# --------- Mood & Chakra Charts ---------
if not df.empty:
    st.subheader(" Mood Trends")
    mood_counts = df["Mood"].value_counts()
    st.bar_chart(mood_counts)

    st.subheader(" Chakra Attention Frequency")
    chakra_counts = df["Chakra"].value_counts()
    st.bar_chart(chakra_counts)

# --------- PDF Generation ---------
def create_pdf(entry_data):
    pdf = FPDF()
    pdf.add_page()

    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="Spiritual Wellness Entry", ln=True, align="C")
    pdf.ln(10)

    # Add entry details to PDF
    for column, value in entry_data.items():
        pdf.cell(200, 10, txt=f"{column}: {value}", ln=True)

    return pdf

# --------- PDF Download Button ---------
if st.button(" Download Entry as PDF"):
    entry_data = {
        "Date": date,
        "Mood": mood,
        "Chakra": chakra,
        "Dream": dream,
        "Rituals": ", ".join(rituals),
        "Moon Phase": moon_phase,
        "Notes": notes
    }

    pdf = create_pdf(entry_data)
    
    # Save PDF to a file
    pdf_output = "spiritual_wellness_entry.pdf"
    pdf.output(pdf_output)

    # Offer download
    with open(pdf_output, "rb") as f:
        st.download_button("Download PDF", f, file_name=pdf_output)

